This directory contains several programs that I (Greg Dietsche) wrote while testing KerNO.
Some of these programs can and will cause the loss of data. All of these programs are unsupported.

ErrorSimulator	-	Simulates various error conditions that may be encountered.
				note that KerNO does *not* recover all errors that can be simulated

retval 		-	A simple program that always returns a value of 10.

retval2		-	A simple program that always places the value 10 in a variable called result.

bigr			-	A 37.5635K executable.

FLINE			-	Demonstrates All possible F-Line instuctions on AMS 2.04 - 2.08... and probabbly for many AMS
				versions to come...
